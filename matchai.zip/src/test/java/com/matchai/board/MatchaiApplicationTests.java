package com.matchai.board;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MatchaiApplicationTests {

	@Test
	void contextLoads() {
	}

}
