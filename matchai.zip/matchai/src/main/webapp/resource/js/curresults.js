let selectedLeague = 'kbo'; // Default league

document.addEventListener("DOMContentLoaded", function() {
	populateYearOptions();
	selectMonth(new Date().getMonth() + 1);
	document.getElementById('year').addEventListener('change', updateCalendar);

	// 로고 버튼 클릭 시
	document.getElementById('btn-logo').addEventListener('click', function() {
		window.location.href = '/board/main';
	});

	// 로그인, 로그아웃, 회원가입 버튼 요소를 가져옴
	const loginButton = document.getElementById('btn-login');
	const logoutButton = document.getElementById('btn-logout');
	const signupButton = document.getElementById('btn-signup');

	// 로그인 버튼이 존재하면 클릭 이벤트 리스너 추가
	if (loginButton) {
		// 로그인 버튼 클릭 시, 로그인 주소로 이동
		loginButton.addEventListener('click', function() {
			window.location.href = '/user/login';
		});
	}

	// 로그아웃 버튼이 존재하면 클릭 이벤트 리스너 추가
	if (logoutButton) {
		// 로그아웃 버튼 클릭 시, 로그아웃 주소로 이동
		logoutButton.addEventListener('click', function() {
			window.location.href = '/user/logout';
		});
	}

	// 회원가입 버튼이 존재하면 클릭 이벤트 리스너 추가
	if (signupButton) {
		// 회원가입 버튼 클릭 시, 회원가입 주소로 이동
		signupButton.addEventListener('click', function() {
			window.location.href = '/user/signup';
		});
	}

});

function populateYearOptions() {
	const currentYear = new Date().getFullYear();
	const yearSelect = document.getElementById('year');

	for (let year = 2000; year <= currentYear; year++) {
		let option = document.createElement('option');
		option.value = year;
		option.text = year;
		yearSelect.appendChild(option);
	}
	yearSelect.value = currentYear;
}

function selectLeague(league) {
	selectedLeague = league;
	updateCalendar();
}

function selectMonth(month) {
	const monthNames = ["1월", "2월", "3월", "4월", "5월", "6월", "7월", "8월", "9월", "10월", "11월", "12월"];
	document.getElementById('month-header').innerText = monthNames[month - 1];
	populateCalendar(month);
}

function updateCalendar() {
	const selectedMonth = document.getElementById('month-header').innerText.replace('월', '');
	selectMonth(parseInt(selectedMonth));
}

function populateCalendar(month) {
	const yearSelect = document.getElementById('year');
	const selectedYear = yearSelect.value;
	const daysInMonth = new Date(selectedYear, month, 0).getDate();
	const firstDay = new Date(selectedYear, month - 1, 1).getDay();

	let calendarBody = '';
	let dayCount = 1;

	for (let i = 0; i < 6; i++) {
		calendarBody += '<tr>';
		for (let j = 0; j < 7; j++) {
			if (i === 0 && j < firstDay) {
				calendarBody += '<td><div class="inner"></div></td>';
			} else if (dayCount <= daysInMonth) {
				calendarBody += `<td><span class="day">${dayCount}</span><div class="inner"><ul></ul></div></td>`;
				dayCount++;
			} else {
				calendarBody += '<td><div class="inner"></div></td>';
			}
		}
		calendarBody += '</tr>';
		if (dayCount > daysInMonth) break;
	}

	document.getElementById('calendar-body').innerHTML = calendarBody;
	fetchGameResults(selectedYear, month);
}

function fetchGameResults(year, month) {
	const url = '/board/getCurResults'; // 절대 경로로 설정
	const data = {
		selLeague: selectedLeague,
		selYear: String(year),
		selMonth: month < 10 ? '0' + month : String(month) // Ensure month is a string
	};

	fetch(url, {
		method: 'POST',
		headers: {
			'Content-Type': 'application/json'
		},
		body: JSON.stringify(data)
	})
		.then(response => {
			if (!response.ok) {
				throw new Error(`HTTP error! status: ${response.status}`);
			}
			return response.json();
		})
		.then(results => {
			console.log('Fetched game results:', results);
			updateCalendarWithResults(results);
		})
		.catch(error => console.error('Error fetching game results:', error));
}


function updateCalendarWithResults(results) {
	const year = document.getElementById('year').value;
	const month = document.getElementById('month-header').innerText.replace('월', '').trim();
	const days = document.querySelectorAll('.day');

	days.forEach(dayElement => {
		const day = dayElement.innerText;
		const date = `${year}-${month < 10 ? '0' + month : month}-${day < 10 ? '0' + day : day}`;

		results.forEach(game => {
			if (game.game_date === date) {
				const inner = dayElement.nextElementSibling.querySelector('.inner ul');
				const gameInfo = `${game.winteam} ${game.winscore} - ${game.losescore} ${game.loseteam}`;
				const li = document.createElement('li');
				li.textContent = gameInfo;
				inner.appendChild(li);
			}
		});
	});
}

function startUnity() {
	window.location.href = '/board/unity';
}

function loginPlz() {
	alert("로그인 후 사용가능 합니다.")
}

